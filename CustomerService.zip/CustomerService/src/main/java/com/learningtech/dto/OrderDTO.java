package com.learningtech.dto;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.learningtech.entity.Customer;
import com.learningtech.entity.ShippingAddress;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@JsonInclude(Include.NON_NULL )
public class OrderDTO {
	
	private String orderId;
	private String orderTrackingNum;
	private Integer totalQuantity;
	private Double totalPrice;
	private String orderStatus;
	private Date deliveryDate;
	private String paymentStatus;
	private String razorPayOrderId;
	private String razorPayPaymentId;
	private String invoiceUrl;
	private Customer customer;
	private ShippingAddress shippingAddress;

}
