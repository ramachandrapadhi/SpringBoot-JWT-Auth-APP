package com.learningtech.dto;

import java.util.Set;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.learningtech.entity.Order;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@JsonInclude(Include.NON_NULL )
public class ShippingAddressDTO {
	private String shippingAddressId;
	private String houseNum;
	private String street;
	private String city;
	private String state;
	private String zipcode;
	private String country;
	private Set<Order> order;
}
