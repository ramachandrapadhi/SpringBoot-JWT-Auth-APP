package com.learningtech.dto;

import lombok.Data;

@Data
public class CustomerLoginDTO {

	private String email;
	private String password;

}
