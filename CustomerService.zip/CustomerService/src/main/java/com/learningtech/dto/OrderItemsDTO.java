package com.learningtech.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.learningtech.entity.Order;
import com.learningtech.entity.Product;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@JsonInclude(Include.NON_NULL)
public class OrderItemsDTO {

	private String orderItemId;
	private String imageUrl;
	private Double uniPrice;
	private Integer quantity;
	private Product product;
	private Order order;

}
