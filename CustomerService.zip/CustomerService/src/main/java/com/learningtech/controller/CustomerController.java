package com.learningtech.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.learningtech.dto.CustomerDTO;
import com.learningtech.dto.CustomerLoginDTO;
import com.learningtech.dto.LoginResponse;
import com.learningtech.dto.ResetPasswordDTO;
import com.learningtech.service.ICustomerService;
import com.learningtech.utils.GenericResponse;
import com.learningtech.utils.GenericResponseUtil;
import com.learningtech.utils.MessageConstants;

@RestController
@RequestMapping("/customer")
public class CustomerController {
	
	private static Logger logger = LoggerFactory.getLogger(CustomerController.class);
	
	@Autowired
	private ICustomerService customerService;
	
	@GetMapping("/health")
	public ResponseEntity<GenericResponse> gethealth() {
		return GenericResponseUtil.createBuildRsponseMsg(HttpStatus.OK, "Customer service is running ");
	}
	@GetMapping("/msg")
	public ResponseEntity<GenericResponse> gethealthMsg() {
		return GenericResponseUtil.createBuildRsponseMsg(HttpStatus.OK, "Authorized endpoint");
	}
	
	@GetMapping("/getAll")
	public ResponseEntity<GenericResponse> getAllActive() {
		List<CustomerDTO> all = customerService.getAllActiveCustomer();
		return GenericResponseUtil.createBuildRsponse(all, HttpStatus.OK, MessageConstants.RETRIVE_MSG);
	}
	@PostMapping("/login")
	public ResponseEntity<GenericResponse> login(@RequestBody CustomerLoginDTO customerLoginDTO ) {
		LoginResponse<CustomerDTO> customerDto = customerService.login(customerLoginDTO);
		return GenericResponseUtil.createBuildRsponse(customerDto, HttpStatus.OK, MessageConstants.LOGIN_SUCCESS);
	}
	
	@PostMapping("/register")
	private ResponseEntity<GenericResponse> register(@RequestBody CustomerDTO customerDTO) {
		CustomerDTO registeredUser = customerService.register(customerDTO);
		return GenericResponseUtil.createBuildRsponse(registeredUser, HttpStatus.OK, MessageConstants.SUCCESS_CREATE);
	}
	@PutMapping("/update")
	private ResponseEntity<GenericResponse> updateCustomer(@RequestBody CustomerDTO customerDTO) {
		CustomerDTO registeredUser = customerService.updateCustomer(customerDTO);
		return GenericResponseUtil.createBuildRsponse(registeredUser, HttpStatus.OK, MessageConstants.SUCCESS_CREATE);
	}
	@PutMapping("/resetpassword")
	private ResponseEntity<GenericResponse> resetpassword(@RequestBody ResetPasswordDTO resetPasswordDTO) {
		boolean isPasswordUpdated = customerService.resetpassword(resetPasswordDTO);
		logger.info("Is password update successfully {}",isPasswordUpdated);
		return GenericResponseUtil.createBuildRsponseMsg(HttpStatus.OK, "Password Updated successfully");
	}
	
	@PostMapping("/forgot-pwd/{email}")
	private ResponseEntity<GenericResponse> forgotPwd(@PathVariable("email") String email) {
		boolean status = customerService.forgotPwd(email);
		logger.info("Is forgotPwd mail sent {}",status);
		if(status) {
			return GenericResponseUtil.createBuildRsponseMsg(HttpStatus.OK, "Password sent to your email");
		}
		return GenericResponseUtil.createErrorRsponseMsg(HttpStatus.BAD_REQUEST, "Not able to send mail");
	}
}
