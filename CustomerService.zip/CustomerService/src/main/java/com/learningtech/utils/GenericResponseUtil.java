package com.learningtech.utils;

import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.lang.NonNull;

/*
 * This Class responsible for generate Generic response either success or error 
 * 
*/
public abstract class GenericResponseUtil {
	/*
	 * This method use in success response 
	 * 
	 * @Param data        will set data in response
	 * @Param status      Will set status code of response 
	 * @Param message     Will set message in response 
	*/
	public static ResponseEntity<GenericResponse> createBuildRsponse(Object data, HttpStatus status,String message){
		GenericResponse response = GenericResponse.builder()
				.message(message)
				.status(Boolean.TRUE)
				.data(data)
				.statusCode(status.value())
				.build();
		return new ResponseEntity<>(response,status);
	}
	
	/*
	 * This method use in success response when ever we need to send only message 
	 * 
	 * @Param status      Will set status code of response 
	 * @Param message     Will set message in response 
	*/
	public static ResponseEntity<GenericResponse> createBuildRsponseMsg(HttpStatus status,String message){
		GenericResponse response = GenericResponse.builder()
				.message(message)
				.status(Boolean.TRUE)
				.statusCode(status.value())
				.build();
		return new ResponseEntity<>(response,status);
	}
	
	/*
	 * This method use in error response 
	 * 
	 * @Param data        will set data in response
	 * @Param status      Will set status code of response 
	 * @Param message     Will set message in response 
	*/
	public static ResponseEntity<GenericResponse> createErrorRsponse(Object data, HttpStatus status,String message){
		GenericResponse response = GenericResponse.builder()
				.message(message)
				.status(Boolean.FALSE)
				.data(data)
				.statusCode(status.value())
				.build();
		return new ResponseEntity<>(response,status);
	}
	
	/*
	 * This method use in error response when ever we need to send only message 
	 * 
	 * @Param status      Will set status code of response 
	 * @Param message     Will set message in response 
	*/
	public static ResponseEntity<GenericResponse> createErrorRsponseMsg(HttpStatus status,String message){
		GenericResponse response = GenericResponse.builder()
				.message(message)
				.status(Boolean.FALSE)
				.statusCode(status.value())
				.build();
		return new ResponseEntity<>(response,status);
	}
	
	
	/*
	 * This method use in success response 
	 * 
	 * @Param page        will set data in response
	 * @Param status      Will set status code of response 
	 * @Param message     Will set message in response 
	 * @Param message     targetClass need to pass page type class
	*/
	public static <T, P> ResponseEntity<GenericResponse> createBuildPageRsponse(@NonNull Page<P> page, @NonNull HttpStatus status,@NonNull String message,@NonNull Class<T> targetClass){
		GenericResponse response = GenericResponse.builder()
				.message(message)
				.status(Boolean.TRUE)
				.data(null)
				.statusCode(status.value())
				.build();
		
		
		response = GenerateResponseData.setData(response, page, targetClass);
		
		return new ResponseEntity<>(response,status);
	}
}
