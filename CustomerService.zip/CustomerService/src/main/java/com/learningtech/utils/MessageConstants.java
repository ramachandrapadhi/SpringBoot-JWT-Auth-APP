package com.learningtech.utils;

public class MessageConstants {
	
	public static String SUCCESS_CREATE="Created Successfully";
	public static String SUCCESS_UPDATE="Updated Successfully";
	public static String RETRIVE_MSG="Data Retrived Successfully";
	public static String SUCCESS="Success";
	public static String LOGIN_SUCCESS="Login Success";
	public static String ERROR="Some error occured please try after sometime";
	
	

}
