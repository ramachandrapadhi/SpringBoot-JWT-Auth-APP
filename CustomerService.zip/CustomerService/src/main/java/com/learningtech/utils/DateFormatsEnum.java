package com.learningtech.utils;

public class DateFormatsEnum {

	public enum DATE_FORMATS {
		DATE_FORMAT_DD_MMM_YYYY_HH_MM("dd-MMM-yyyy hh:mm aaa"),
		DATE_FORMAT_DD_MMM_YYYY("dd-MMM-yyyy"),
		DATE_FORMAT_YYYY_MM_DD("yyyy-MM-dd"),
		DATE_FORMAT_MM_DD_YYYY("MM/dd/yyyy"), 
		DATE_FORMAT_MM_DD_YY_HH_MM_A("MM/dd/yy hh:mm a"),
		DATE_FORMAT_YYYY_MM_DD_HH_MM("yyyy-MM-dd  HH:mm"),
		DATE_FORMAT_YYYY_MM_DD_HH_MM_SS("yyyy-MM-dd' 'HH:mm:ss"),
		DATE_FORMAT_YYYY_MM_DD_HH_MM_A("yyyy-MM-dd' 'hh:mm a"),
		DATE_FORMAT_YYYY_MM_DD_1SPACE_HH_MM("yyyy-MM-dd HH:mm"),
		DATE_FORMAT_USER_MGMT_SOLR_UPDATES("yyyy-MM-dd'  'HH:mm"),
		DATE_FORMAT_DD_MMM_YYYY_HH24_MM("dd-MMM-yyyy HH:mm");

		String format = "";

		private DATE_FORMATS(String format) {
			this.format = format;
		}

		public String getFormat() {
			return format;
		}
	}
}
