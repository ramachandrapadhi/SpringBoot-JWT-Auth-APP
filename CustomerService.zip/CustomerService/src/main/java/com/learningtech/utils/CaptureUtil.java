package com.learningtech.utils;

import java.sql.Timestamp;
import java.util.UUID;

import com.learningtech.entity.BaseEntity;


public interface CaptureUtil {
	
	public static  void created(BaseEntity model ) {
		
		model.setCreatedAt(getTimeStamp());
//		TODO need to change hard coded value 
		model.setCreatedBy("Admin");
	}
	
	public static void update(BaseEntity model) {
		model.setUpdatedAt(getTimeStamp());
//		TODO need to change hard coded value 
		model.setUpdatedBy("Admin");
	}
	
	private static Timestamp getTimeStamp() {
		return new Timestamp(System.currentTimeMillis()) ;
//		String timeStamp = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new java.util.Date());
//		return  Timestamp.valueOf(timeStamp);
	}
	
	public static String getId() {
//		String uniqueID = UUID.randomUUID().toString();
//		return uniqueID.replaceAll("[^0-9a-zA-Z]", "");
		return UUID.randomUUID().toString().replaceAll("[^0-9a-zA-Z]", "");
	}

}
