package com.learningtech.utils;

import java.util.List;

import org.springframework.beans.BeanUtils;
import org.springframework.data.domain.Page;
import org.springframework.lang.NonNull;

import lombok.Data;

public interface  GenerateResponseData {
	
	/*This method use to set list of data for pagination 
	 * 
	 * @param GenericResponse empty genericResponse object to set data 
	 * @param page List of data need to set
	 *
	*/
	public static <T, S> GenericResponse setData(@NonNull GenericResponse genericResponse, @NonNull Page<S> page, @NonNull Class<T> target){
		PageDataObj obj = new PageDataObj();
		
		List<S> content = page.getContent();
		T t = BeanUtils.instantiateClass(target);
		
		obj.setListOfdata(BeanMapperUtils.copy(content, t.getClass()));
		obj.setPageNo(page.getNumber()+1);
		obj.setPageSize(page.getSize());
		obj.setTotalRecord((int)page.getTotalElements());
		obj.setTotalpages(page.getTotalPages());
		genericResponse.setData(obj);
		return genericResponse;
	}
	/*This method use to set list of data like array of data for drop down 
	 * 
	 * @param GenericResponse empty genericResponse object to set data 
	 * @param page List of data need to set
	 *
	*/
	public static <T> GenericResponse setData(@NonNull GenericResponse genericResponse, @NonNull List<T> listOfData) {
		DataObj obj = new DataObj();
		obj.setData(listOfData);
		obj.setTotalRecord(listOfData != null ? listOfData.size() : 0);
		genericResponse.setData(obj);
		return genericResponse;
	}
	
	@Data
	public class PageDataObj{
		private Integer pageSize;
		private Integer pageNo;
		private Integer totalRecord;
		private Integer totalpages;
		private Object  listOfdata;
	}
	@Data
	public class DataObj{
		private Object data;
		private Integer totalRecord;
	}

}