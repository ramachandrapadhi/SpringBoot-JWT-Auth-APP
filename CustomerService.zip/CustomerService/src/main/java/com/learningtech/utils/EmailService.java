package com.learningtech.utils;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;

import jakarta.mail.internet.MimeMessage;
import lombok.SneakyThrows;

@Service
public class EmailService {

	private static Logger logger = LoggerFactory.getLogger(EmailService.class);

	@Autowired
	private static JavaMailSender mailSender;
	
	private static final String FROM_MAIL="learningtech.ram@gmail.com";

	@SneakyThrows
	public  boolean sendEmail(String to, String subject, String body) {

		try {
			MimeMessage mimeMessage = mailSender.createMimeMessage();

			MimeMessageHelper helper = new MimeMessageHelper(mimeMessage);
			
			helper.setFrom(FROM_MAIL);
			helper.setTo(to);
			helper.setSubject(subject);
			helper.setText(body, true);

			mailSender.send(mimeMessage);
			logger.info("Mail sent successfully to {}", to);

			return true;
		} catch (Exception e) {
			logger.error("Facing some error while sending mail {}", e.getLocalizedMessage());
		}
		return false;
	}
}
