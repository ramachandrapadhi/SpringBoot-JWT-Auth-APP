package com.learningtech.utils;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.BeanUtils;
import org.springframework.lang.NonNull;

public abstract class BeanMapperUtils {
	
	/*
	 *  @param source the source bean
	 *  @param target the target bean
	*/
		
	public static <S, T> T copy(@NonNull S source, @NonNull Class<T> target) {
		T instantiateClass = BeanUtils.instantiateClass(target);
		BeanUtils.copyProperties(source, instantiateClass);
		return instantiateClass;
	}

	/*
	 * @param sourceList the sourceList need to convert
	 * @param type bean need to convert 
	*/
	public static <S, T> List<T> copy(@NonNull List<S> sourceList,@NonNull Class<T> type ) {
	    List<T> targetList = new ArrayList<>(); 
	     for (S source: sourceList ) {
	        T target = BeanUtils.instantiateClass(type);
	        BeanUtils.copyProperties(source , target);
	        targetList.add(target);
	     }
		return targetList;
	}
}
