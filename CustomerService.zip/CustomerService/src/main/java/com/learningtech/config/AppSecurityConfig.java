package com.learningtech.config;

import java.util.Arrays;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.config.Customizer;
import org.springframework.security.config.annotation.authentication.configuration.AuthenticationConfiguration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.CorsConfigurationSource;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;

import com.learningtech.service.impl.CustomCustomerService;
import lombok.SneakyThrows;

@Configuration
@EnableWebSecurity
public class AppSecurityConfig {
	
	public static final String[] UN_PROTECTED_API_LIST = {
			"/customer/health",
			"/customer/register",
			"/customer/login",
			"/customer/resetpassword",
			"/customer/forgot-pwd/**",
			};
	
	@Autowired
	private CustomCustomerService customCustomerService;
	
	@Autowired
	private JWTAuthenticationFilter jwtAuthFilter;
	
	@Bean
	BCryptPasswordEncoder pwdEncoder() {
		return new BCryptPasswordEncoder();
	}
	
	@Bean
	AuthenticationProvider authPovider() {
		DaoAuthenticationProvider authProvider = new DaoAuthenticationProvider();
		authProvider.setUserDetailsService(customCustomerService);
		authProvider.setPasswordEncoder(pwdEncoder());
		return authProvider;
	}
	
	@Bean
	@SneakyThrows
	AuthenticationManager authManager(AuthenticationConfiguration config) {
		return config.getAuthenticationManager();
	}
	
	@Bean
	@SneakyThrows
	SecurityFilterChain securityFilterChain(HttpSecurity http) {
		
		http
		.csrf(csrf -> csrf.disable())
		.authorizeHttpRequests(req-> {
			req.requestMatchers(UN_PROTECTED_API_LIST)
			.permitAll()
			.anyRequest()
			.authenticated();
		})
		.sessionManagement(session -> session.sessionCreationPolicy(SessionCreationPolicy.STATELESS))
		.addFilterBefore(jwtAuthFilter, UsernamePasswordAuthenticationFilter.class)
		.authenticationProvider(authPovider()).formLogin(Customizer.withDefaults())
		.httpBasic(Customizer.withDefaults())
		.cors(cors-> cors.configurationSource(crosConfig()))
		;
		return http.build();
	}
//	used for CORS error
	private CorsConfigurationSource crosConfig() {

		CorsConfiguration configuration = new CorsConfiguration();
		configuration.setAllowedOrigins(Arrays.asList("*"));
		configuration.setAllowedMethods(Arrays.asList("*"));
		configuration.setAllowedHeaders(Arrays.asList("*"));
		configuration.setMaxAge(3600l);
		UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
		source.registerCorsConfiguration("/**", configuration);
		return source;
	}
}
