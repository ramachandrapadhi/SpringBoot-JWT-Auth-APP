package com.learningtech.config;

import java.io.IOException;
import java.util.Arrays;

import org.springframework.http.HttpStatus;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.web.authentication.WebAuthenticationDetailsSource;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import com.learningtech.utils.GenericResponse;

import io.jsonwebtoken.ExpiredJwtException;

import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import lombok.RequiredArgsConstructor;

@Component
@RequiredArgsConstructor
public class JWTAuthenticationFilter extends OncePerRequestFilter {
	
	final private JWTService jwtservice;

	final private UserDetailsService userDetailsService;
	

	@Override
	protected void doFilterInternal(
			HttpServletRequest request, 
			HttpServletResponse response, 
			FilterChain filterChain) throws ServletException, IOException {
		
		response.setContentType("application/json");
		response.setCharacterEncoding("UTF-8");
		final String authHeader = request.getHeader("Authorization");
		final String jwtToken;
		final String userName;
		String path = request.getRequestURI().substring(request.getContextPath().length());
		if (authHeader == null || !authHeader.startsWith("Bearer ")) {
			if (isUnprotected(path)) {
				filterChain.doFilter(request, response);
				return;
			}
			
			setResponse(response,HttpStatus.UNAUTHORIZED.getReasonPhrase());
			return;
		}
		jwtToken = authHeader.substring(7);
		
		try {
			userName = jwtservice.extractUserName(jwtToken);
			if (userName != null && SecurityContextHolder.getContext().getAuthentication() == null) {

				UserDetails user = this.userDetailsService.loadUserByUsername(userName);
				if (jwtservice.isTokenValid(jwtToken, user)) {
					UsernamePasswordAuthenticationToken authtoken = new UsernamePasswordAuthenticationToken(user, null,	user.getAuthorities());
					authtoken.setDetails(new WebAuthenticationDetailsSource().buildDetails(request));
					SecurityContextHolder.getContext().setAuthentication(authtoken);
				} else {
					setResponse(response,HttpStatus.UNAUTHORIZED.getReasonPhrase());
				}
			}
		} catch (ExpiredJwtException e) {
			setResponse(response,HttpStatus.UNAUTHORIZED.getReasonPhrase());
			return;
		}
		filterChain.doFilter(request, response);
	}
	
	private boolean isUnprotected(String path) {
		return Arrays.asList(AppSecurityConfig.UN_PROTECTED_API_LIST).contains(path);
	}
	
	private void setResponse(HttpServletResponse response,String message) throws JsonProcessingException, IOException {
		
		GenericResponse genericResponse = GenericResponse.builder()
												.message(message)
												.status(Boolean.FALSE)
												.statusCode(HttpStatus.UNAUTHORIZED.value())
												.build();
		ObjectMapper mapper = new ObjectMapper();
		response.getWriter().write(mapper.writeValueAsString(genericResponse));
		response.setStatus(HttpStatus.UNAUTHORIZED.value());
	}

}
