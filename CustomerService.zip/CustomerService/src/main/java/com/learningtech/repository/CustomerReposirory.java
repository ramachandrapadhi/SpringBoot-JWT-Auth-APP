package com.learningtech.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.learningtech.entity.Customer;

public interface CustomerReposirory extends JpaRepository<Customer, String> {
	public Optional<Customer> findByEmail(String email);
	public Optional<Customer> findByEmailAndPwd(String email,String password);
	
//	public Optional<Users> findByUsersNameAndPassword(String username,String password);

}
