package com.learningtech.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.learningtech.entity.ShippingAddress;

public interface ShippingAddressRepository extends JpaRepository<ShippingAddress, String> {

}
