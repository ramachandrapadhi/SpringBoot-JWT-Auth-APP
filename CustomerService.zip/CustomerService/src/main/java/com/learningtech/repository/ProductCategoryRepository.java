package com.learningtech.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.learningtech.entity.ProductCategory;

public interface ProductCategoryRepository extends JpaRepository<ProductCategory, String> {
	
	List<ProductCategory> findByStatus(Boolean status);

}
