package com.learningtech.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.learningtech.entity.Product;

public interface ProductRepository extends JpaRepository<Product, String> {
	
	Optional<List<Product>> findByProductCategoryCategoryId(String catId);
	
	Optional<List<Product>> findByName(String name);

}
