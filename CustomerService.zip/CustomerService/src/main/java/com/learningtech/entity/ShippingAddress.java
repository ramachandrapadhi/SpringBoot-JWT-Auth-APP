package com.learningtech.entity;

import java.util.Set;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Getter
@Setter
@Builder
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "shipping_address")
@EqualsAndHashCode(callSuper=false)
public class ShippingAddress extends BaseEntity{
	
	private static final long serialVersionUID = 103L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.UUID)
	@Column(name="shipping_address_id", nullable = false)
	private String shippingAddressId;
	
	@Column(name="house_num", nullable = false)
	private String houseNum;
	
	@Column(name="street", nullable = false)
	private String street;
	
	@Column(name="city", nullable = false)
	private String city;
	
	@Column(name="state", nullable = false)
	private String state;
	
	@Column(name="zipcode", nullable = false)
	private String zipcode;
	
	@Column(name="country", nullable = false)
	private String country;
	
	@OneToMany(mappedBy = "shippingAddress")
	private Set<Order> order;

}
