package com.learningtech.entity;


import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Getter
@Setter
@Builder
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "order_items")
@EqualsAndHashCode(callSuper=false)
public class OrderItems extends BaseEntity {
	
	private static final long serialVersionUID = 106L;
	
	@Id
//	@GeneratedValue(strategy = GenerationType.UUID)
	@Column(name="order_item_id",nullable = false)
	private String orderItemId;
	
	@Column(name="image_url")
	private String imageUrl;
	
	@Column(name="unit_price")
	private Double uniPrice;
	
	@Column(name="quantity")
	private Integer quantity;
	
	
	@OneToOne
	@JoinColumn(name = "product_id")
	private Product product;  
	
	@OneToOne
	@JoinColumn(name = "order_id")
	private Order order;  
}
