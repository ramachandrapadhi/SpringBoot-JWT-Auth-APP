package com.learningtech.entity;

import java.util.Set;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@EqualsAndHashCode(callSuper=false)
@Builder
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "product_category")
public class ProductCategory extends BaseEntity{
	
	private static final long serialVersionUID = 101L;

	@Id
//	@GeneratedValue(strategy = GenerationType.UUID)
	@Column(name="category_id")
	private String categoryId;	

	@Column(name="category_name")
	private String categoryName;
	
	@Column(name="status")
	private Boolean status;
	
	@OneToMany(mappedBy = "productCategory") 
	private Set<Product> products ;
	
}
