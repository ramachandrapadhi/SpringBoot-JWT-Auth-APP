package com.learningtech.entity;

import java.util.Set;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;

import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Getter
@Setter
@Builder
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "customer")
@EqualsAndHashCode(callSuper=false)
public class Customer extends BaseEntity {
	
	private static final long serialVersionUID = 103L;
	
	@Id
//	@GeneratedValue(strategy = GenerationType.UUID)
	@Column(name="customer_id")
	private String customerId;
	
	@Column(name="customer_name", nullable = false)
	private String customerName;
	
	@Column(name="email", nullable = false,unique = true)
	private String email;
	
	@Column(name="pwd")
	private String pwd;
	
	@Column(name="phno", nullable = false,unique = true)
	private String phno;
	
	@Column(name="pwd_updated", nullable = false)
	private String pwdUpdated;
	
	@Column(name="status", nullable = false)
	private String status;
	
	@OneToMany(mappedBy = "customer") 
	private Set<Order> order;

}
