package com.learningtech.entity;

import java.util.Date;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Getter
@Setter
@Builder
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "order_tab")
@EqualsAndHashCode(callSuper=false)
public class Order extends BaseEntity{
		
		private static final long serialVersionUID = 104L;

		@Id
//		@GeneratedValue(strategy = GenerationType.UUID)
		@Column(name="order_id",nullable = false)
		private String orderId;
		
		@Column(name="order_tracking_num")
		private String orderTrackingNum;
		
		@Column(name="total_quantity")
		private Integer totalQuantity;
		
		@Column(name="total_price")
		private Double totalPrice;
		
		@Column(name="order_status")
		private String orderStatus;
		
		@Column(name="delivery_date")
		private Date deliveryDate;
		
		@Column(name="payment_status")
		private String paymentStatus;
		
		@Column(name="razor_pay_order_id")
		private String razorPayOrderId;
		
		@Column(name="razor_pay_payment_id")
		private String razorPayPaymentId;
		
		@Column(name="invoice_url")
		private String invoiceUrl;
		
		@ManyToOne(fetch = FetchType.LAZY, cascade = CascadeType.ALL)
		@JoinColumn(name = "customer_id", nullable = false)
		private Customer customer;
		
		@ManyToOne(fetch = FetchType.LAZY, cascade = CascadeType.ALL)
		@JoinColumn(name = "shipping_address_id", nullable = false)
		private ShippingAddress shippingAddress;

}
