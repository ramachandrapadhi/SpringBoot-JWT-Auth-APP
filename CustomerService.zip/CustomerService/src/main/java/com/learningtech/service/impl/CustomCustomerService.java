package com.learningtech.service.impl;

import java.util.Collections;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.learningtech.entity.Customer;
import com.learningtech.repository.CustomerReposirory;

@Service
public class CustomCustomerService implements UserDetailsService{

	@Autowired
	private CustomerReposirory customerRepo;

	
	@Override
	public UserDetails loadUserByUsername(String email) throws UsernameNotFoundException {
		Customer customer = customerRepo.findByEmail(email).orElseThrow(()-> new BadCredentialsException("Invalid Email/Password"));
		return new User(customer.getEmail(),customer.getPwd(),Collections.emptySet());
	}

}
