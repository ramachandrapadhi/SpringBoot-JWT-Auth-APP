package com.learningtech.service.impl;

import java.util.List;
import java.util.Optional;
import java.util.Random;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.util.ObjectUtils;

import com.learningtech.config.JWTService;
import com.learningtech.dto.CustomerDTO;
import com.learningtech.dto.CustomerLoginDTO;
import com.learningtech.dto.LoginResponse;
import com.learningtech.dto.ResetPasswordDTO;
import com.learningtech.entity.Customer;
import com.learningtech.repository.CustomerReposirory;
import com.learningtech.service.ICustomerService;
import com.learningtech.utils.BeanMapperUtils;
import com.learningtech.utils.CaptureUtil;
import com.learningtech.utils.EmailService;

@Service
public class CustomerService implements ICustomerService {
	
	private static Logger logger = LoggerFactory.getLogger(CustomerService.class);

	@Autowired
	private CustomerReposirory customerRepo;
	
	@Autowired
	private EmailService emailService;
	
	@Autowired
	private BCryptPasswordEncoder encoder;
	
	@Autowired
	private AuthenticationManager authenticationManager;
	
	@Autowired
	private JWTService jwtService;
	
	@Autowired
	private CustomCustomerService customCustomerService;
	
	
	@Override
	public LoginResponse<CustomerDTO> login(CustomerLoginDTO customerLoginDTO) {
		
		if(!ObjectUtils.isEmpty(customerLoginDTO)) {
			
			UsernamePasswordAuthenticationToken uToken = new UsernamePasswordAuthenticationToken(
					customerLoginDTO.getEmail(), customerLoginDTO.getPassword());
			Authentication authenticate = authenticationManager.authenticate(uToken);
			
			boolean isSuccess = authenticate.isAuthenticated();
			if(isSuccess) {
				Customer customer = customerRepo.findByEmail(customerLoginDTO.getEmail())
										.orElseThrow(()-> new IllegalArgumentException("Invalid Email/Password"));
				
				CustomerDTO customerDTO = BeanMapperUtils.copy(customer, CustomerDTO.class);
				UserDetails userDetails = customCustomerService.loadUserByUsername(customerLoginDTO.getEmail());
				 
				String jwt_token = jwtService.generateToken(userDetails);
				long exporyIn = jwtService.getExpiryTime(jwt_token);
				return new LoginResponse<CustomerDTO>(jwt_token,exporyIn+" min",customerDTO);
			}else {
				throw new BadCredentialsException("Invalid Email/Password");
			}
		}
		return null;
	}

	@Override
	public CustomerDTO register(CustomerDTO customerDTO) {
	
		if(!ObjectUtils.isEmpty(customerDTO)) {
			if(isUniqueMail(customerDTO.getEmail())) {
				Customer customer = BeanMapperUtils.copy(customerDTO, Customer.class);
				customer.setCustomerId(CaptureUtil.getId());
				String encodedPassword = encoder.encode(getRemdomPassword());
				customer.setPwd(encodedPassword);
				customer.setPwdUpdated("No");
				CaptureUtil.created(customer);
				customer.setStatus("active");
				
				Customer savedCustomer = customerRepo.save(customer);
				
				if(!ObjectUtils.isEmpty(savedCustomer)) {
					String mailBody = "You have registered in Shopping cart & here is the one time login password : <b>"
							+customer.getPwd()+" </b> please login and reset your password"  ;
					emailService.sendEmail(customer.getEmail(), "Password Reset", mailBody);
					return BeanMapperUtils.copy(customer, CustomerDTO.class);
				}
			}else {
				throw new IllegalArgumentException("Already have account with this email");
			}
		}
		return null;
	}

	@Override
	public Boolean isUniqueMail(String email) {
		Optional<Customer> userOpt = customerRepo.findByEmail(email);
		return !userOpt.isPresent();
	}
	

	@Override
	public Boolean resetpassword(ResetPasswordDTO resetPasswordDTO) {
		if(!ObjectUtils.isEmpty(resetPasswordDTO)) {
			
			if(!resetPasswordDTO.getNewPassword().equals(resetPasswordDTO.getConfirmPassword())) {
				throw new IllegalArgumentException("New password and confirm password not same");
			}
			Optional<Customer> opt = customerRepo.findByEmail(resetPasswordDTO.getEmail());
			if(opt.isPresent()) {
				Customer customer = opt.get();
				if(encoder.matches(resetPasswordDTO.getOldPassword(), customer.getPwd())) {
					String encodedPassword = encoder.encode(resetPasswordDTO.getNewPassword());
					customer.setPwd(encodedPassword);
					customer.setPwdUpdated("Yes");
					CaptureUtil.update(customer);
					customerRepo.save(customer);
					return true;
				}else{
					throw new IllegalArgumentException("Old password is not correct");
				}
			}else {
				throw new IllegalArgumentException("No Account found By Email : "+resetPasswordDTO.getEmail());
			}
		}
		return false;
	}
	
	
	@Override
	public Boolean forgotPwd(String email) {
		
		Optional<Customer> opt = customerRepo.findByEmail(email);
		if(opt.isPresent()) {
			Customer customer = opt.get();
			
			String mailBody = "You have requested for forgot password plase click <b><a href=\"https://www.w3schools.com\">here</a></b> to reset password ";
			emailService.sendEmail(customer.getEmail(), "Reset Password Request", mailBody);
			
		}else {
			throw new IllegalArgumentException("No Account found By Email : "+email);
		}
		
		
		return null;
	}
	
	
	@Override
	public CustomerDTO updateCustomer(CustomerDTO usersDTO) {
		
		Customer customer = getCustById(usersDTO.getCustomerId());
		
		customer.setPhno(usersDTO.getPhno());
		customer.setCustomerName(usersDTO.getCustomerName());
		customer.setEmail(usersDTO.getEmail());
		
		CaptureUtil.update(customer);
		customer = customerRepo.save(customer);
		
		return BeanMapperUtils.copy(customer, CustomerDTO.class);
	}
	

	@Override
	public CustomerDTO getCustomerById(String customerID) {
		Customer customer = getCustById(customerID);
		return BeanMapperUtils.copy(customer, CustomerDTO.class);
	}

	@Override
	public List<CustomerDTO> getAllActiveCustomer() {
		List<Customer> customerList = customerRepo.findAll();
		return BeanMapperUtils.copy(customerList, CustomerDTO.class);
	}
	
	
	@Override
	public CustomerDTO getCustomerByEmail(String email) {
		Optional<Customer> opt = customerRepo.findByEmail(email);
		Customer customer = opt.orElseThrow(()->new IllegalArgumentException("No data dound by ID "+email));
		return BeanMapperUtils.copy(customer, CustomerDTO.class);
	}

	private Customer getCustById(String id) {
		Optional<Customer> opt = customerRepo.findById(id);
		return opt.orElseThrow(()->new IllegalArgumentException("No data dound by ID "+id));
	}
	private String getRemdomPassword() {
		String SALTCHARS = "ABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890";
		StringBuilder salt = new StringBuilder();
		Random rnd = new Random();
		while (salt.length() < 6) { // length of the random string.
			int index = (int) (rnd.nextFloat() * SALTCHARS.length());
			salt.append(SALTCHARS.charAt(index));
		}
		logger.error("The Password for the User is : {}",salt.toString());
		return salt.toString();
	}

	

	
}
