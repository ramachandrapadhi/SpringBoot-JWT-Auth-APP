package com.learningtech.service;


import java.util.List;

import com.learningtech.dto.CustomerDTO;
import com.learningtech.dto.CustomerLoginDTO;
import com.learningtech.dto.LoginResponse;
import com.learningtech.dto.ResetPasswordDTO;

public interface ICustomerService {
	
	public LoginResponse<CustomerDTO> login(CustomerLoginDTO usersDTO);
	public CustomerDTO register(CustomerDTO usersDTO);
	public CustomerDTO updateCustomer(CustomerDTO usersDTO);
	public Boolean isUniqueMail(String email);
	public Boolean resetpassword(ResetPasswordDTO resetPasswordDTO);
	
	public CustomerDTO getCustomerById(String customerID);
	public CustomerDTO getCustomerByEmail(String email);
	public List<CustomerDTO> getAllActiveCustomer();
	public Boolean forgotPwd(String email);

}
