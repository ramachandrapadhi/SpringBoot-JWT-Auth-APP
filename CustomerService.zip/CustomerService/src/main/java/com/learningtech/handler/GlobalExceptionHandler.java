package com.learningtech.handler;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.AuthenticationException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import com.learningtech.utils.GenericResponse;

@RestControllerAdvice
public class GlobalExceptionHandler {
	
	@ExceptionHandler(AuthenticationException.class)
	public ResponseEntity<GenericResponse> handleBadCredentialsException(AuthenticationException e) {
		return new ResponseEntity<>(
				GenericResponse.builder()
				.message("Invalid Email/Password")
				.status(Boolean.FALSE)
				.statusCode(HttpStatus.BAD_REQUEST.value())
				.build(),
				HttpStatus.BAD_REQUEST);
		
	}
	@ExceptionHandler(IllegalArgumentException.class)
	public ResponseEntity<GenericResponse> handleIllegalArgumentException(IllegalArgumentException e) {

		return new ResponseEntity<>(
				GenericResponse.builder()
				.message(e.getLocalizedMessage())
				.status(Boolean.FALSE)
				.statusCode(HttpStatus.BAD_REQUEST.value())
				.build(),
				HttpStatus.BAD_REQUEST);

	}
	@ExceptionHandler({ RuntimeException.class })
	public ResponseEntity<GenericResponse> handleRuntimeException(RuntimeException e) {
		
		return new ResponseEntity<>(
				GenericResponse.builder()
				.message(e.getLocalizedMessage())
				.status(Boolean.FALSE)
				.statusCode(null).build(),
				HttpStatus.INTERNAL_SERVER_ERROR);
		
	}
}
